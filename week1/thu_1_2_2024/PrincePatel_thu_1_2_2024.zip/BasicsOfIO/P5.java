import java.util.Scanner;

public class P5 {
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        String[] arr=sc.nextLine().split(" ");
        System.out.println("number of words are "+arr.length);
        sc.close();
}
    
}