public class P1 {
    public static void main(String[] args) {
        System.out.println(circleArea(10));
    }
    static float circleArea(float r){
        return (float)Math.PI*r*r;
    }
}
