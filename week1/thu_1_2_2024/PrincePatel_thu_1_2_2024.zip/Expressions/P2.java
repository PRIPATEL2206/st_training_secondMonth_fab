public class P2 {
    public static void main(String[] args) {
        System.out.println("calcius of "+230+" is : "+fToC(230));
    }
    static float fToC(float f){
        return (f-32)*5/9;
    }
}
