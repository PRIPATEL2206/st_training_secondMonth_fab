public class P3 {
    public static void main(String[] args) {
        System.out.println("sum of 100 is "+sumOfN(100));
    }
    static int sumOfN(int n){
        return n*(n+1)/2;
    }
}
