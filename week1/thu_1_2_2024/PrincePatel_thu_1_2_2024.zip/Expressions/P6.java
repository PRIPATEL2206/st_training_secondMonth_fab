public class P6 {
    public static void main(String[] args) {
        int n=225;
        System.out.println("square root  of "+n+" is "+Math.sqrt(n));
    }
}
