public class P7 {
    public static void main(String[] args) {
        System.out.println("average  of 4 , 6 , 8 is " + avg(4, 6, 8));
    }

    static float avg(float a, float b, float c) {
        return (a + b + c) / 3;
    }
}
