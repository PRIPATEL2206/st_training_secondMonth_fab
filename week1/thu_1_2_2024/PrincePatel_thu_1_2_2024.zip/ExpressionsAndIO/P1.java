import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        System.out.println("enter options");
         Scanner sc = new Scanner(System.in);
         String op = sc.nextLine();
         while (op.toLowerCase()=="q") {
            System.out.println("1: for calcius to farenheat"); 
            System.out.println("2: for calcius to farenheat"); 
            System.out.println("q: for exit"); 
            op = sc.nextLine();
        }
        sc.close();
    }

    static float fToC(float f) {
        return (f - 32) * 5 / 9;
    }

    static float cToF(float c) {
        return c * 9 / 5 + 32;
    }
}
